import "./Products.css";
import Product from "../Product/Product";

export default function Products({ prop }) {
  return (
    <section className="Products-products">
      {prop.map((v) => (
        <Product
          key={v.id}
          id={v.id}
          title={v.title}
          price={v.price}
          description={v.description}
          category={v.category}
          image={v.image}
          ratingRate={v.rating.rate}
          ratingCount={v.rating.count}
        />
      ))}
    </section>
  );
}
