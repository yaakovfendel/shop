import "./Product.css";

export default function Product(prop) {
  return (
    <div className="Product-product-card">
      <div className="Product-product-image" id={prop.id}>
        <img src={prop.image} alt="" />
      </div>
      <div className="Product-product-info">
        <h5>{prop.title}</h5>
        <h6>{prop.price}</h6>
      </div>
      <div>
        <h6>{prop.description}</h6>
        <h5>{prop.category}</h5>
      </div>
      <div>
        <h6>{prop.ratingRate}</h6>
        <h6>{prop.ratingCount}</h6>
      </div>
    </div>
  );
}
